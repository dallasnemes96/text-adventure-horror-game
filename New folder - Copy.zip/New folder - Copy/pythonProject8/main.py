import random

x = ["You are not welcome here.", "They know you are here. They are waiting.", "You are never going to leave here",
     "I remember your father. Your brother is still here"]

y = random.choice(x)

print("""You finally arrived at the doorstep to the mansion your father and brother were last seen. 
The Varga Family Manor. 
Built in 1798. 
Do you: 
1. enter the mansion front's door 
or 
2. walk down the stone path? 

(door/path)

""")


def front_door():
    print("""You enter the door to the mansion. 
Where do you go now?
There is a:
1. hallway 
or 
2. some stairs in the foyer.

(hallway/foyer)

 """)


def foyer():
    print("""You walk up the stairs in the foyer. 
You encounter a door to the left and a door to the right. 
Which do you choose
left
or
right
""")


def left():
    print("""You attempt to open the door but get electrocutred by a trap and die.
Game Over """)


def right():
    print("""You enter the room and a strange woman in a french maid outfit is smoking a cigarette and drinking a martini. 
'Well hello Charles, how are you doing? 
I have been waiting for your arrival, now please excuse me, but, I basically own you now. 
Your father's flesh was better tasting than your brother's. 
I hope your's is the best of them all.' 
The door locks from behind you and the woman laughs maniacally while holding a revolver to your face at point blank. 
Do you run and jump out the window or try to talk your way out of this? (run/talk) """)


def run():
    print(""" You run to the window, jump, smash your way through the glass as you fall to the ground, you land badly and roll your ankle. 
Do you now run to the entrance of the courtyard or to the nearby shed? (entrance/shed """)


def entrance():
    print(""" You limp away to safety and flag down a car to pick you up. It happens to be a 1960's sedan. 
You hop inside, the strange woman is there in the driver's seat, pointing a revolver at you. 
'Charles, you can NEVER leave once you enter, i hope you know that.' 
Game over """)


def shed():
    print(""" You limp to the shed, and are approached by a groundskeeper on an oxygen tank. 
He murmers indeciecevly, then pulls out his revolver and shoots you. 
Game over. 
You NEVER hide when injured """)


def talk():
    print(""" 'There is nothing you can say to save yourself i have been starving for flesh and organs for too long now.' 
You cry out: 'Why are you doing this?' 
The strage woman says, 'Because darling, it's a woman's world'. 
The woman pulls out her letter opener and stabs you into the eye, killing you. 
Game over. """)


def run_away():
    print("""You run to the window, jump, smash your way through the glass as you fall to the ground, you land badly and roll your ankle. 
Do you now:
1. run to the entrance of the courtyard 
or 
2. to the nearby shed? 
(entrance/shed)
""")


def path():
    print("""You walk along a stone path for a bit and notice a greenhouse.
Do you want to:
1. continue down the path
or
2. investigate the greenhouse? 
(pathway/greenhouse) 
""")


def pathway():
    print("""You walk along the path further. 
You notice through the fence a black car is following you. 
You reach a door. 
Do you open the door? 
or
Turn around?
(open door/turn around) """)


def open_door():
    print("""You walk into a kitchen area and are greeted by brunette woman in a french maid outfit. 
She offers you a martini and a cigarette. 
Do you accept or decline? 
(accept drink/decline drink) """)


def accept_drink():
    print("""You take a sip and light up the cigarette. 
The woman says: 
'So tell me about yourself Charles.' 
You think to yourself how could this strange woman possibly know your name? 
You tell her that your father and brother went missing here and you were looking for them. 
She then explains: 
'Oh dear, the family is all complete. 
They were returned where they belong. 
Here in the walls of this house is where they remain. 
Now that you sipped that drink, now you will NEVER leave!!!' 
You begin to feel very disoriented and throw your glass at the woman and run. 
You see a hallway you can go down or some stairs you can go up. 
(hallway2, stairs2) """)


def hallway2():
    print("""You are running down the hallway and lost the strange woman. 
You continue running and run into an old frail man in a suit. 
He blocks your path. 
Do you attempt to continue your path or turn around? 
(continue2/turn around2) """)


def stairs2():
    print(
        """You run up the stairs only to be hit over the back of the head with a baseball bat. You wake up in a bedroom tied to a table. The strange woman is there staring you down while sipping her martini. She rubs her fingers over the gash on the back of your head, collects some blood to mix into her martini. 'Now darling, stop screaming for help. You are part of the family, you will never leave. Now are you going to comply or not? (yes/no) """)


def hallway():
    print(""" You walk down a long hallway lit with candles and decorated with family portraits.
As you walk, you catch a glimpse of a portrait that oddly looks like your father.
Do you:
1. Investigate the portrait
or
2. Continue to walk

(portrait/walk) """)


def portrait():
    print("""You approach the portrait. You notice not only does the person resemble your father, but he has the same name as your father. 
You immediately begin to feel naseaus, disoriented, and fall to your knees.
You turn around and there is a deformed little girl holding a letter opener.
She says: 'Why issss it that i only am the one, with one working eye. IT'S NOT FAIR! 
You get stabbed in the eye and bleed out.

Game Over""")


def walk():
    print("""You continue walking down the hallway and encounter an old man in a tuxedo pushing a tray full of drinks.
Before you even noticed, he was already staring at you, blank face, and not saying a single word. 
You are face to face with him. 
Do you:
1. Ask him about the mansion
2. Take a drink
3. Walk passed him 

(question/drink/walk2) """)


def question():
    print(""" The man stares at you and gives no answer. 
Then he mutters out through his stoma '1969'. 
Do you ask again or walk away? 
(again/walk away) """)


def again():
    print(
        """ The old butler mutters through his stoma """ + y + """Your metal state becomes increasingly unstable and your gut tells you to run. You run down the hallway and see a downward stairwell and an opening to a parlor. (stairwell/parlor """)


def stairwell():
    print("""You fall down the stairwell, hitting your head several times, pass out, and bleed to death. Game over """)


def parlor():
    print("""You enter the parlor where a woman in a french maid costume, and a deformed man in a wheelchair are sitting and drinking at a table. 
You hear a revolver click anmd feel it pressed against your back.
You are escorted over to the table.
The couple say:
'Welcome to the family, Charles!' 
You are then stabbed by the woman in the eye and bleed out.
Game over. """)


def drink():
    print(""" You drank hydroclorhic acid and died.

COME ON, DID THIS HONESTLY SEEM LIKE A GOOD IDEA IN THE SLIGHTEST? 
IT IS A GODDAMN NOOB TRAP. 
BIG GAME OVER """)


def walk2():
    print(""" The old butler stabs you in the kidney with a triangular knife as you try to walk by him. 
You fall over, bleed out and die. 
Game over.""")


def greenhouse():
    print("""You walk up to the greenhouse and attempt to open it but it is locked. 
A man in overalls and on an oxygen tank comes up from behind and startles you. 
He says 
'Are you trying to break into the Royal Varga family's greenhouse??? 
All intruders must be exterminated!!' 
Do you sprint or try to reason with the groundskeeper? 
(sprint /reason)""")


def sprint():
    print("""You attempt to run away towards some woods. 
You hide behind a tree. 
You look to your left and there is a deformed girl holding a revolver. 
Before you can even reason, she shoots you. 
Game over""")


def reason():
    print("""'But sir i can expla-'
He hits you in the head with his oxygen tank. 
You are dead. 
Game over""")


ask1 = input().lower().strip()
if ask1 == "door":
    front_door()
elif ask1 == "path":
    path()

ask2 = input().lower().strip()
if ask2 == "hallway":
    hallway()
elif ask2 == "foyer":
    foyer()

ask4 = input().lower().strip()
if ask4 == "portrait":
    portrait()
elif ask4 == "walk":
    walk()

ask5 = input().lower().strip()
if ask5 == "left":
    left()
elif ask5 == "right":
    right()

ask3 = input().lower().strip()
if ask3 == "pathway":
    pathway()
elif ask3 == "greenhouse":
    greenhouse()

ask6 = input().lower().strip()
if ask6 == "question":
    question()
elif ask6 == "drink":
    drink()
elif ask6 == "walk2":
    walk2()

ask7 = input().lower().strip()
if ask7 == "run away":
    run_away()
elif ask7 == "talk":
    talk()

ask8 = input().lower().strip()
if ask8 == "entrance":
    entrance()
elif ask8 == "shed":
    shed()

ask9 = input().lower().strip()
if ask9 == "again":
    again()
elif ask9 == "walk away":
    walk_away()

ask10 = input().lower().strip()
if ask10 == "open door":
    open_door()
elif ask10 == "turn around":
    turn_around()

ask11 = input().lower().strip()
if ask11 == "accept drink":
    accept_drink()
elif ask11 == "decline drink":
    decline_drink()

ask12 = input().lower().strip()
if ask12 == "stairs2":
    stairs2()
elif ask12 == "hallway2":
    hallway2()

ask13 = input().lower().strip()
if ask13 == "continue2":
    continue2()
elif ask13 == "turn around2":
    turn_around2()

ask14 - input().lower().strip()
if ask14 == "sprint":
    sprint()
if ask14 == "reason":
    reason()